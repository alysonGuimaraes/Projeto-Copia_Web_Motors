<?php
include('../configs/dbconnection.php');
session_start();


if ($_REQUEST['botao'] == 'Entrar') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_encrypted = md5($password);

    $sql = "SELECT * FROM users WHERE username = '$username' AND senha = '$senha'";
    $result = mysqli_query($con, $sql);

    while ($linha=mysqli_fetch_array($result)){
        $_SESSION["id_usuario"]=$linha["id"];
        $_SESSION["nome_usuario"]=$linha["username"];
        $_SESSION["nivelUsuario"]=$linha["level"];

    $level = $linha['level'];
        
    if ($level == 'USR'){
        header("Location: index.php");
        exit;
    }
    }    
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login</title>
  <link rel="stylesheet" href="../styles/login.css">
</head>
<body>

  <div class="header">
    <h1>Webmotors Copia</h1>
  </div>

  <div class="login-container">
    <div class="login-box">
      <div class="email-login">
        <h2>Digite o seu e-mail e senha</h2>
        <input type=text placeholder="Usuário" name=username/>
        <input type="password" placeholder="Senha" />
        <button class="login-btn" name="botao" value="Entrar">Entrar</button>
      </div>
    </div>
  </div>

  <div class="footer">
    Não tem uma conta? <a href="cadastro_user.php">Crie a sua</a>
  </div>

</body>
</html>