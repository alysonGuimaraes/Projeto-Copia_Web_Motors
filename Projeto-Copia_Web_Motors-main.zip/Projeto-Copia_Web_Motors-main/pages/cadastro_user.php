<?php

require('../configs/dbconnection.php');

if ($_REQUEST['botao'] == 'Cadastrar') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $hashed_password = md5($password);

    $query = "INSERT INTO users (username, password, level) VALUES ('$username', '$hashed_password', 'USR')";
    $result = mysqli_query($con, $query);

    if ($result) {
        echo "Usuário cadastrado com sucesso!";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar</title>
    <link rel="stylesheet" href="../styles/login.css">
</head>
<body>
    <h2>Cadastro de Usuário</h2>
    <form method="POST">
        <label for="username">Nome de Usuário:</label><br>
        <input type="text" id="username" name="username" required><br><br>
        <label for="password">Senha:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" name="botao" value="Cadastrar">
    </form>

    <div class="footer">
        Já tem uma conta? <a href="login.php">Entre agora</a>
    </div>
</body>
</html>