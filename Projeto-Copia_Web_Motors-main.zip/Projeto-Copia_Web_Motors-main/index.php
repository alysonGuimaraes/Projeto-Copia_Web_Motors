<?php


?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Carros à venda</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Ícones Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Estilo personalizado -->
    <link rel="stylesheet" href="styles/paginaInicial.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light px-4 py-3 border-bottom">
        <a class="navbar-brand fw-bold text-danger" href="#">WebmotorsClone</a>
        <div class="collapse navbar-collapse justify-content-between">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="#">Comprar</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Vender</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Serviços</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Notícias</a></li>
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Busque por marca ou modelo">
                <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
            </form>
            <div class="ms-3">
                <a  href="pages/login.php"> 
                    <i class="bi bi-person-circle fs-4 me-3 btn"></i>
                </a>
                <i class="bi bi-heart fs-4 me-3"></i>
                <i class="bi bi-chat-left-dots fs-4"></i>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <div class="row">
            <!-- Filtros -->
            <aside class="col-3 px-4">
                <h6 class="fw-bold mb-3">Filtros aplicados <i class="bi bi-exclamation-circle-fill text-danger"></i></h6>
                <a href="#" class="d-block text-decoration-none mb-2">Limpar todos</a>

                <div class="btn-group mb-3 w-100" role="group">
                    <button class="btn btn-dark">Carros</button>
                    <button class="btn btn-outline-dark">Motos</button>
                </div>

                <div class="mb-3">
                    <label class="form-label">Localização</label>
                    <input type="text" class="form-control" placeholder="Digite sua cidade ou estado">
                </div>

                <div class="mb-3">
                    <label class="form-label">Novo/Usado</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="novo">
                        <label class="form-check-label" for="novo">Novos (0)</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="usado">
                        <label class="form-check-label" for="usado">Usados (0)</label>
                    </div>
                </div>

                <div>
                    <label class="form-label">Marca</label>
                    <div class="d-flex flex-wrap gap-2">
                        <span class="brand-box">Chevrolet</span>
                        <span class="brand-box">Fiat</span>
                        <span class="brand-box">Ford</span>
                        <span class="brand-box">Honda</span>
                        <span class="brand-box">Hyundai</span>
                        <span class="brand-box">Mitsubishi</span>
                    </div>
                </div>
            </aside>


            <main class="col-9 d-flex justify-content-center align-items-center flex-column text-center">
                <img src="https://cdn-icons-png.flaticon.com/512/8371/8371263.png" alt="Nenhum resultado" width="200">
                <h4 class="mt-4">Ops, não encontramos nenhum resultado para a sua busca</h4>
                <p class="text-muted">Limpe os filtros e tente novamente</p>
            </main>
        </div>
    </div>

</body>
</html>
