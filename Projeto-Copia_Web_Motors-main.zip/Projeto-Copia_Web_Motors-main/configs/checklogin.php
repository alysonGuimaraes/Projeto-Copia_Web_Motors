<?php
session_start();

if(!isset($SESSION["id_usuario"]) || !isset($SESSION["nome_usuario"])){
    header("Location: login.php");
    exit;
}
?>